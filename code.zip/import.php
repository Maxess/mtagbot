<?php
/**
 * Multi-Step Import Wizard (CSV & XLSX with Ambiguity Detection & Queueing)
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/academic_year_helpers.php';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/importer.php';

require_permission('import_data');

$step = $_GET['step'] ?? 1;
$sessionId = (int)($_GET['session_id'] ?? 0);

// Step 1 -> Upload file & Create Session
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_file') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash_message('error', 'خطای امنیتی CSRF');
        redirect('import.php');
    }
    if (isset($_FILES['import_file']) && $_FILES['import_file']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['import_file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['csv', 'xlsx', 'xls'])) {
            set_flash_message('error', 'فرمت فایل انتخابی مجاز نیست. لطفاً فایل CSV یا XLSX آپلود کنید.');
            redirect('import.php');
        }

        $destFolder = __DIR__ . '/uploads';
        if (!is_dir($destFolder)) mkdir($destFolder, 0777, true);
        
        $newFilename = 'import_' . time() . '.' . $ext;
        $destPath = $destFolder . '/' . $newFilename;
        move_uploaded_file($_FILES['import_file']['tmp_name'], $destPath);

        // Parse rows
        $rows = parse_any_import_file($destPath);
        $totalRows = count($rows);

        // Detect ambiguities
        $ambiguities = [];
        foreach ($rows as $idx => $r) {
            $nid = trim($r['national_id'] ?? '');
            if (empty($nid)) {
                $ambiguities[] = [
                    'row_index' => $idx,
                    'type'      => 'missing_nid',
                    'message'   => 'کد ملی وارد نشده است. سیستم می‌تواند هویت موقت ایجاد کند.',
                    'data'      => $r
                ];
            }
        }

        // Save to import_sessions
        $previewJson = json_encode(array_slice($rows, 0, 50), JSON_UNESCAPED_UNICODE) ?: '[]';
        $ambJson     = json_encode(array_slice($ambiguities, 0, 50), JSON_UNESCAPED_UNICODE) ?: '[]';
        
        DB::execute(
            "INSERT INTO import_sessions (admin_id, filename, file_type, status, total_rows, processed_rows, preview_data, ambiguities_data, created_at) VALUES (?, ?, ?, 'preview', ?, 0, ?, ?, NOW())",
            [$_SESSION['admin_id'] ?? 1, $newFilename, $ext, $totalRows, $previewJson, $ambJson]
        );
        $newSessionId = DB::lastInsertId();
        if (!$newSessionId) {
            $last = DB::fetch("SELECT id FROM import_sessions ORDER BY id DESC LIMIT 1");
            $newSessionId = $last ? $last['id'] : 1;
        }

        // If file is very large (> 500 rows), offer queueing
        if ($totalRows > 500) {
            DB::execute("INSERT INTO import_queue (session_id, file_path, status) VALUES (?, ?, 'queued')", [$newSessionId, $destPath]);
        }

        log_activity($_SESSION['admin_id'], 'آپلود فایل ایمپورت', "فایل $newFilename با $totalRows ردیف آپلود شد.");
        redirect("import.php?step=2&session_id=$newSessionId");
    } else {
        set_flash_message('error', 'خطا در بارگذاری فایل. لطفاً مجدداً تلاش کنید.');
        redirect('import.php');
    }
}

// Step 3 -> Execute Import
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'execute_import') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash_message('error', 'خطای امنیتی CSRF');
        redirect('import.php');
    }
    $sid = (int)($_POST['session_id'] ?? 0);
    $session = DB::fetch("SELECT * FROM import_sessions WHERE id = ?", [$sid]);
    if ($session) {
        $filepath = __DIR__ . '/uploads/' . $session['filename'];
        $rows = parse_any_import_file($filepath);
        $processed = 0;

        // Target academic year from selector (overrides CSV) - NEW v4.28.22
        $targetYearInput = trim($_POST['target_academic_year'] ?? '');
        $targetYearUnified = $targetYearInput !== '' ? unify_academic_year($targetYearInput) : '';

        // Group rows by student + class + term + month
        $groupedReports = [];
        foreach ($rows as $r) {
            $nid = trim($r['national_id'] ?? '');
            if (empty($nid)) {
                $nid = 'TEMP-' . rand(100000, 999999);
            }
            $csvYear = unify_academic_year(trim($r['academic_year'] ?? '1402-1403'));
            $effectiveYear = $targetYearUnified !== '' ? $targetYearUnified : $csvYear;
            $key = $nid . '|' . $effectiveYear . '|' . trim($r['term'] ?? 'نوبت اول') . '|' . trim($r['report_month'] ?? 'مهر');
            if (!isset($groupedReports[$key])) {
                $groupedReports[$key] = [
                    'student' => [
                        'national_id' => $nid,
                        'first_name'  => trim($r['first_name'] ?? 'بدون نام'),
                        'last_name'   => trim($r['last_name'] ?? 'بدون نام خانوادگی'),
                        'father_name' => trim($r['father_name'] ?? ''),
                        'birth_date'  => trim($r['birth_date'] ?? ''),
                        'grade_level' => trim($r['grade_level'] ?? 'دهم'),
                        'class_name'  => trim($r['class_name'] ?? '101'),
                        'is_temp'     => strpos($nid, 'TEMP-') === 0 ? 1 : 0
                    ],
                    'report' => [
                        'academic_year' => $effectiveYear,
                        'term'          => trim($r['term'] ?? 'نوبت اول'),
                        'report_month'  => trim($r['report_month'] ?? 'مهر'),
                        'class_name'    => trim($r['class_name'] ?? '101')
                    ],
                    'grades' => []
                ];
            }
            $groupedReports[$key]['grades'][] = [
                'subject_name' => trim($r['subject_name'] ?? 'درس عمومی'),
                'score'        => (float)($r['score'] ?? 0),
                'max_score'    => (float)($r['max_score'] ?? 20),
                'coefficient'  => (float)($r['coefficient'] ?? 1),
            ];
            $processed++;
        }

        // Insert / Update DB
        foreach ($groupedReports as $grp) {
            $st = $grp['student'];
            // Match existing student smartly (normalized name/class/NID)
            $student = match_existing_student($st['first_name'] . ' ' . $st['last_name'], $st['first_name'], $st['last_name'], $grp['report']['class_name'], $st['national_id']);
            if ($student) {
                $studentId = $student['id'];
                DB::execute("UPDATE students SET class_name=?, grade_level=? WHERE id=?", [$grp['report']['class_name'], $st['grade_level'], $studentId]);
            } else {
                // Do NOT insert new students during report import as strictly instructed by user
                continue;
            }

            // Check class
            $cls = DB::fetch("SELECT id FROM classes WHERE name = ?", [$grp['report']['class_name']]);
            if (!$cls) {
                DB::execute("INSERT INTO classes (name, grade, academic_year) VALUES (?, ?, ?)", [$grp['report']['class_name'], $st['grade_level'], $grp['report']['academic_year']]);
            }

            // Calculate GPA
            $totalWeightedScore = 0;
            $totalCoeff = 0;
            foreach ($grp['grades'] as $g) {
                $totalWeightedScore += ($g['score'] * $g['coefficient']);
                $totalCoeff += $g['coefficient'];
            }
            $gpa = $totalCoeff > 0 ? round($totalWeightedScore / $totalCoeff, 2) : 0;

            // Check or insert report
            $rep = DB::fetch("SELECT id FROM reports WHERE student_id = ? AND academic_year = ? AND term = ? AND report_month = ?",
            [$studentId, $grp['report']['academic_year'], $grp['report']['term'], $grp['report']['report_month']]);
            
            if ($rep) {
                $reportId = $rep['id'];
                DB::execute("UPDATE reports SET total_score = ?, gpa = ? WHERE id = ?", [$totalWeightedScore, $gpa, $reportId]);
                DB::execute("DELETE FROM report_grades WHERE report_id = ?", [$reportId]);
            } else {
                DB::execute("INSERT INTO reports (student_id, class_name, academic_year, term, report_month, total_score, gpa) VALUES (?, ?, ?, ?, ?, ?, ?)",
                [$studentId, $grp['report']['class_name'], $grp['report']['academic_year'], $grp['report']['term'], $grp['report']['report_month'], $totalWeightedScore, $gpa]);
                $reportId = DB::lastInsertId();
            }

            // Insert grades
            foreach ($grp['grades'] as $g) {
                $status = $g['score'] >= 10 ? 'passed' : 'failed';
                DB::execute("INSERT INTO report_grades (report_id, subject_name, score, max_score, coefficient, status) VALUES (?, ?, ?, ?, ?, ?)",
                [$reportId, $g['subject_name'], $g['score'], $g['max_score'], $g['coefficient'], $status]);
            }
        }

        standardize_all_class_names();
        DB::execute("UPDATE import_sessions SET status = 'completed', processed_rows = ? WHERE id = ?", [$processed, $sid]);
        log_activity($_SESSION['admin_id'], 'اجرای موفق ایمپورت', "نشست ID: $sid با $processed رکورد پردازش شد.");
        set_flash_message('success', "عملیات ایمپورت با موفقیت انجام شد و $processed نمره ثبت گردید.");
        redirect("import.php?step=4&session_id=$sid");
    }
}

// Fetch session info if step > 1
$currentSession = null;
if ($sessionId > 0) {
    $currentSession = DB::fetch("SELECT * FROM import_sessions WHERE id = ?", [$sessionId]);
}
$recentSessions = DB::fetchAll("SELECT * FROM import_sessions ORDER BY id DESC LIMIT 5");
?>
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <div>
            <h2 class="text-2xl font-bold">⚡ ایمپورت چندمرحله‌ای (Wizard) کارنامه</h2>
            <p class="text-sm text-muted">آپلود، پیش‌نمایش، تشخیص ابهام، رفع تعارض‌ها و تایید نهایی</p>
        </div>
        <a href="Report.csv" download class="btn btn-outline gap-1 text-sm border-blue-500 text-blue-600">
            <span>📥 دانلود نمونه فایل ساختاریافته (Report.csv)</span>
        </a>
    </div>

    <!-- Wizard Bar -->
    <div class="wizard-steps card">
        <div class="wizard-step <?php echo $step >= 1 ? 'active' : ''; ?>">۱. بارگذاری فایل</div>
        <div class="wizard-step <?php echo $step >= 2 ? 'active' : ''; ?>">۲. پیش‌نمایش و بررسی ابهام</div>
        <div class="wizard-step <?php echo $step >= 3 ? 'active' : ''; ?>">۳. تایید نهایی و پردازش</div>
        <div class="wizard-step <?php echo $step >= 4 ? 'completed' : ''; ?>">۴. نتیجه اجرای ایمپورت</div>
    </div>

    <?php if ($step == 1): ?>
    <div class="grid grid-cols-2 gap-6">
        <div class="card">
            <h3 class="font-bold mb-4 text-primary">آپلود فایل جدید کارنامه‌ها</h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <input type="hidden" name="action" value="upload_file">
                <div class="mb-4">
                    <label class="block text-xs font-semibold mb-2">انتخاب فایل (CSV یا XLSX)</label>
                    <input type="file" name="import_file" class="form-input p-2" accept=".csv,.xlsx,.xls" required>
                    <small class="text-xs text-muted block mt-1">حداکثر حجم فایل مجاز: ۱۰ مگابایت. کدگذاری پیشنهادی: UTF-8</small>
                </div>
                <div class="p-3 bg-blue-50 rounded border border-blue-200 text-xs mb-4">
                    <p class="font-bold mb-1">راهنمای ستون‌های الزامی:</p>
                    <code>national_id, first_name, last_name, class_name, academic_year, term, report_month, subject_name, score, coefficient</code>
                </div>
                <button type="submit" class="btn btn-primary w-full py-2.5">آپلود و ورود به مرحله پیش‌نمایش &larr;</button>
            </form>
        </div>

        <div class="card">
            <h3 class="font-bold mb-4">نشست‌های اخیر ایمپورت (Session Versioning)</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>شناسه</th>
                            <th>نام فایل</th>
                            <th>وضعیت</th>
                            <th>رکوردها</th>
                            <th>ادامه</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentSessions as $sess): ?>
                        <tr>
                            <td class="font-mono">#<?php echo $sess['id']; ?></td>
                            <td class="font-mono text-xs dir-ltr truncate max-w-xs"><?php echo clean($sess['filename']); ?></td>
                            <td>
                                <?php
                                if ($sess['status']==='completed') $statusBadge = '<span class="badge badge-success">تکمیل‌شده</span>';
                                elseif ($sess['status']==='preview') $statusBadge = '<span class="badge badge-warning">در انتظار تایید</span>';
                                else $statusBadge = '<span class="badge badge-info">' . $sess['status'] . '</span>';
                                echo $statusBadge;
                                ?>
                            </td>
                            <td><?php echo tr_num($sess['processed_rows'] . '/' . $sess['total_rows'], 'fa'); ?></td>
                            <td>
                                <?php if ($sess['status'] !== 'completed'): ?>
                                <a href="import.php?step=2&session_id=<?php echo $sess['id']; ?>" class="btn btn-secondary text-xs px-2 py-1">ادامه &larr;</a>
                                <?php else: ?>
                                <a href="import.php?step=4&session_id=<?php echo $sess['id']; ?>" class="text-xs text-primary">مشاهده</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; if (empty($recentSessions)): ?>
                        <tr><td colspan="5" class="text-center text-muted">تاکنون نشستی ثبت نشده است.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php elseif ($step == 2): 
        if (!$currentSession) {
            echo '<div class="card p-8 text-center"><p class="text-red-600 font-bold mb-4">خطا: اطلاعات پیش‌نمایش نشست ایمپورت یافت نشد.</p><a href="import.php" class="btn btn-primary">آپلود مجدد فایل &larr;</a></div>';
        } else {
            $previewData = json_decode($currentSession['preview_data'] ?? '[]', true) ?: [];
            $ambiguities = json_decode($currentSession['ambiguities_data'] ?? '[]', true) ?: [];
    ?>
    <div class="space-y-6">
        <div class="card bg-amber-50 border-amber-300 p-4">
            <div class="flex justify-between items-center flex-wrap gap-3">
                <div>
                    <h3 class="font-bold text-amber-800">بررسی اولیه فایل: <code><?php echo clean($currentSession['filename']); ?></code></h3>
                    <p class="text-xs text-amber-700 mt-1">تعداد کل رکوردهای شناسایی‌شده: <b><?php echo tr_num($currentSession['total_rows'], 'fa'); ?></b> ردیف | ابهامات شناسایی‌شده: <b><?php echo tr_num(count($ambiguities), 'fa'); ?></b> مورد</p>
                </div>
                <form method="POST" action="import.php" class="flex gap-2 items-end bg-white p-3 rounded border-2 border-indigo-100">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="action" value="execute_import">
                    <input type="hidden" name="session_id" value="<?php echo $currentSession['id']; ?>">
                    <div>
                        <label class="text-xs font-bold">📅 سال تحصیلی مقصد (انتخابی - فرمت جامع - جایگزین سال داخل فایل)</label>
                        <select name="target_academic_year" class="form-select font-bold w-60">
                            <option value="">از داخل فایل (همان سال داخل CSV)</option>
                            <?php foreach(get_academic_years_for_filter() as $yy): ?>
                                <option value="<?php echo clean($yy['academic_year']); ?>" <?php echo get_current_academic_year()===$yy['academic_year']?'selected':''; ?>><?php echo clean($yy['academic_year']); ?><?php echo !empty($yy['is_default'])?' - پیش‌فرض':''; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="text-[10px] text-muted">تمام کارنامه‌ها در سال انتخابی ذخیره می‌شوند</div>
                    </div>
                    <button type="submit" class="btn btn-success px-6 py-2.5 font-bold shadow">
                        <span>✅ تایید و ثبت در سال انتخابی &larr;</span>
                    </button>
                </form>
            </div>
        </div>

        <?php if (!empty($ambiguities)): ?>
        <div class="card border-red-300 bg-red-50">
            <h4 class="font-bold text-red-800 mb-3">⚠️ موارد ابهام یا نقص اطلاعات (نیازمند توجه مدیر):</h4>
            <div class="table-container bg-white rounded border">
                <table>
                    <thead>
                        <tr>
                            <th>ردیف در فایل</th>
                            <th>نوع ابهام</th>
                            <th>توضیحات سیستم</th>
                            <th>نام دانش‌آموز در فایل</th>
                            <th>راهکار سیستم</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($ambiguities, 0, 10) as $amb): ?>
                        <tr>
                            <td>ردیف #<?php echo $amb['row_index'] + 1; ?></td>
                            <td><span class="badge badge-danger"><?php echo $amb['type']; ?></span></td>
                            <td class="text-xs"><?php echo $amb['message']; ?></td>
                            <td class="font-bold"><?php echo clean(($amb['data']['first_name'] ?? '') . ' ' . ($amb['data']['last_name'] ?? '')); ?></td>
                            <td class="text-xs text-green-700 font-semibold">ایجاد خودکار هویت موقت و امکان ویرایش بعدی</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <div class="card">
            <h4 class="font-bold mb-4">پیش‌نمایش ۱۰ ردیف اول فایل بارگذاری‌شده:</h4>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>کد ملی</th>
                            <th>نام و نام خانوادگی</th>
                            <th>کلاس</th>
                            <th>درس</th>
                            <th>نمره</th>
                            <th>ضریب</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($previewData, 0, 10) as $row): ?>
                        <tr>
                            <td class="font-mono text-xs"><?php echo clean($row['national_id'] ?? '---'); ?></td>
                            <td class="font-bold"><?php echo clean(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')); ?></td>
                            <td><?php echo clean($row['class_name'] ?? ''); ?></td>
                            <td><?php echo clean($row['subject_name'] ?? ''); ?></td>
                            <td class="font-bold text-primary"><?php echo clean($row['score'] ?? ''); ?></td>
                            <td><?php echo clean($row['coefficient'] ?? '1'); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php } ?>

    <?php elseif ($step == 4 && $currentSession): ?>
    <div class="card text-center py-8">
        <div class="text-5xl mb-4">✨</div>
        <h2 class="text-2xl font-bold text-green-600 mb-2">ایمپورت با موفقیت انجام شد!</h2>
        <p class="text-sm text-muted mb-6">تعداد <b><?php echo tr_num($currentSession['processed_rows'], 'fa'); ?></b> نمره و کارنامه پردازش و در پایگاه داده ذخیره گردید.</p>
        <div class="flex justify-center gap-4">
            <a href="reports.php" class="btn btn-primary px-6">مشاهده کارنامه‌های ثبت‌شده</a>
            <a href="import.php" class="btn btn-secondary px-6">ایمپورت فایل جدید</a>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
