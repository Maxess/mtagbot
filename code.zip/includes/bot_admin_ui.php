<?php
// File: includes/bot_admin_ui.php
/**
 * Shared production admin UI/controller for Bale and Telegram bots.
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/bot_helpers.php';
require_once __DIR__ . '/school_sort.php';

if (!function_exists('bot_admin_platform_title')) {
    function bot_admin_platform_title($platform) {
        return bot_valid_platform($platform) === 'telegram' ? 'تلگرام' : 'بله';
    }
}

if (!function_exists('bot_admin_webhook_file')) {
    function bot_admin_webhook_file($platform) {
        return bot_valid_platform($platform) === 'telegram' ? 'telegram-webhook.php' : 'bale-webhook.php';
    }
}

if (!function_exists('bot_admin_page_file')) {
    function bot_admin_page_file($platform) {
        return bot_valid_platform($platform) === 'telegram' ? 'telegram-bot.php' : 'bale-bot.php';
    }
}

if (!function_exists('bot_admin_handle_request')) {
    function bot_admin_handle_request($platform) {
        $platform = bot_valid_platform($platform);
        ensure_bot_schema($platform);
        $page = bot_admin_page_file($platform);
        $title = bot_admin_platform_title($platform);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf($_POST['csrf_token'] ?? '')) {
                set_flash_message('error', 'خطای امنیتی CSRF. لطفاً صفحه را دوباره بارگذاری کنید.');
                redirect($page);
            }

            if (isset($_POST['save_bot_token'])) {
                set_setting(bot_token_key($platform), trim($_POST['bot_token'] ?? ''));
                set_flash_message('success', 'توکن ربات ' . $title . ' با موفقیت ذخیره شد.');
                redirect($page);
            }

            if (isset($_POST['send_targeted_message'])) {
                $scope = $_POST['target_scope'] ?? 'all';
                $allowed = ['all', 'grade', 'class', 'student'];
                if (!in_array($scope, $allowed, true)) $scope = 'all';
                $value = trim($_POST['target_value_' . $scope] ?? '');
                $message = trim($_POST['target_message'] ?? '');
                if ($message === '') {
                    set_flash_message('error', 'متن پیام نمی‌تواند خالی باشد.');
                } else {
                    try {
                        $result = bot_send_targeted_text($platform, $scope, $value, $message);
                        log_activity($_SESSION['admin_id'] ?? null, 'ارسال هدفمند ربات ' . $title, "scope=$scope value=$value sent={$result['sent']} failed={$result['failed']}");
                        set_flash_message($result['failed'] ? 'warning' : 'success', "ارسال انجام شد. کل گیرندگان: {$result['total']}، موفق: {$result['sent']}، ناموفق: {$result['failed']}.");
                    } catch (Exception $e) {
                        set_flash_message('error', 'خطا در ارسال پیام: ' . $e->getMessage());
                    }
                }
                redirect($page);
            }

            if (isset($_POST['save_templates'])) {
                foreach (bot_default_messages() as $key => $default) {
                    $txt = trim($_POST['msg_' . $key] ?? $default);
                    DB::execute("INSERT INTO bot_message_templates (platform, template_key, template_text) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE template_text = VALUES(template_text)", [$platform, $key, $txt]);
                }
                foreach (bot_default_buttons() as $b) {
                    $key = $b[0];
                    $txt = trim($_POST['btn_text_' . $key] ?? $b[1]);
                    $row = max(1, (int)($_POST['btn_row_' . $key] ?? $b[3]));
                    $order = max(1, (int)($_POST['btn_order_' . $key] ?? $b[2]));
                    $active = isset($_POST['btn_active_' . $key]) ? 1 : 0;
                    DB::execute("INSERT INTO bot_button_templates (platform, button_key, button_text, sort_order, row_no, is_active) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE button_text = VALUES(button_text), sort_order = VALUES(sort_order), row_no = VALUES(row_no), is_active = VALUES(is_active)", [$platform, $key, $txt, $order, $row, $active]);
                }
                set_flash_message('success', 'متن‌های ثابت و دکمه‌های ربات ' . $title . ' ذخیره شد و بلافاصله در وبهوک اعمال می‌شود.');
                redirect($page);
            }
        }

        if (($_GET['action'] ?? '') === 'set_webhook') {
            if (!verify_csrf($_GET['csrf_token'] ?? '')) {
                set_flash_message('error', 'درخواست تنظیم وبهوک معتبر نیست.');
                redirect($page);
            }
            $token = get_setting(bot_token_key($platform), '');
            if ($token === '') {
                set_flash_message('error', 'ابتدا توکن ربات را ذخیره کنید.');
                redirect($page);
            }
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['PHP_SELF'] ?? '')), '/');
            if ($base === '.') $base = '';
            $webhookUrl = $protocol . $host . $base . '/' . bot_admin_webhook_file($platform);
            try {
                $res = bot_api_request($platform, 'setWebhook', ['url' => $webhookUrl]);
                set_flash_message('success', 'وبهوک ربات ' . $title . ' با موفقیت روی ' . $webhookUrl . ' تنظیم شد.');
                log_activity($_SESSION['admin_id'] ?? null, 'تنظیم وبهوک ربات ' . $title, json_encode($res, JSON_UNESCAPED_UNICODE));
            } catch (Exception $e) {
                set_flash_message('error', 'خطا در تنظیم وبهوک: ' . $e->getMessage());
            }
            redirect($page);
        }
    }
}

if (!function_exists('bot_admin_render_page')) {
    function bot_admin_render_page($platform) {
        $platform = bot_valid_platform($platform);
        $title = bot_admin_platform_title($platform);
        $page = bot_admin_page_file($platform);
        $userTable = bot_user_table($platform);
        $chatCol = $platform === 'telegram' ? 'telegram_chat_id' : 'bale_chat_id';
        $usernameCol = $platform === 'telegram' ? 'telegram_username' : 'bale_username';
        $token = get_setting(bot_token_key($platform), '');
        $adminSecret = get_setting('admin_bot_login_secret', '');
        if ($adminSecret === '') { $adminSecret = bin2hex(random_bytes(8)); set_setting('admin_bot_login_secret', $adminSecret); }
        $connectedUsers = DB::fetchAll("SELECT b.*, b.`$chatCol` AS chat_id, b.`$usernameCol` AS username, s.first_name, s.last_name, s.national_id, s.grade_level, s.class_name FROM `$userTable` b JOIN students s ON b.student_id = s.id ORDER BY b.id DESC LIMIT 200");
        // Target options are unified with students, manual classes and imported weekly schedules.
        $grades = get_unified_grade_options($_GET['year'] ?? get_setting('current_academic_year', '1404/1405'));
        $classes = get_unified_class_options($_GET['year'] ?? get_setting('current_academic_year', '1404/1405'));
        $students = DB::fetchAll("SELECT id, first_name, last_name, national_id, class_name, grade_level FROM students WHERE status = 'active'", []);
        persian_usort_students($students);
        $messages = [];
        foreach (bot_default_messages() as $key => $default) {
            $row = DB::fetch("SELECT template_text FROM bot_message_templates WHERE platform = ? AND template_key = ?", [$platform, $key]);
            $messages[$key] = $row ? $row['template_text'] : $default;
        }
        $buttons = [];
        foreach (bot_default_buttons() as $b) {
            $row = DB::fetch("SELECT * FROM bot_button_templates WHERE platform = ? AND button_key = ?", [$platform, $b[0]]);
            $buttons[$b[0]] = $row ?: ['button_key' => $b[0], 'button_text' => $b[1], 'sort_order' => $b[2], 'row_no' => $b[3], 'is_active' => 1];
        }
        ?>
<div class="space-y-6 bot-admin-page">
    <div class="page-hero flex justify-between items-center">
        <div>
            <h2 class="text-2xl font-bold">🤖 مدیریت ربات <?php echo clean($title); ?></h2>
            <p class="text-sm text-muted">احراز هویت اولیا، دریافت کارنامه تصویری، ارسال هدفمند و سفارشی‌سازی متن‌ها/دکمه‌ها</p>
        </div>
        <div class="flex gap-2">
            <a href="<?php echo $platform === 'telegram' ? 'bale-bot.php' : 'telegram-bot.php'; ?>" class="btn btn-secondary text-xs">رفتن به ربات <?php echo $platform === 'telegram' ? 'بله' : 'تلگرام'; ?></a>
            <a href="sms-panel.php" class="btn btn-outline text-xs">بازگشت</a>
        </div>
    </div>

    <div class="grid grid-cols-3 gap-6 responsive-grid">
        <section class="card shadow-lg space-y-4">
            <h3 class="font-bold text-primary border-b pb-2">تنظیمات توکن و Webhook</h3>
            <form method="POST" class="space-y-3">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <input type="hidden" name="save_bot_token" value="1">
                <label class="block text-xs font-semibold">توکن ربات <?php echo clean($title); ?></label>
                <input type="password" name="bot_token" class="form-input dir-ltr text-left font-mono text-xs" value="<?php echo clean($token); ?>" required>
                <button class="btn btn-primary w-full text-xs" type="submit">💾 ذخیره توکن</button>
            </form>
            <div class="soft-panel text-xs space-y-2">
                <b>آدرس Webhook:</b>
                <code class="block dir-ltr text-left break-all"><?php echo clean(bot_admin_webhook_file($platform)); ?></code>
                <a class="btn btn-success w-full text-xs" href="<?php echo clean($page); ?>?action=set_webhook&amp;csrf_token=<?php echo urlencode(csrf_token()); ?>">⚡ ثبت خودکار Webhook</a>
            </div>
            <div class="soft-panel text-xs">
                <b>لینک/فرمان مخفی ورود مدیر در ربات</b>
                <p class="text-muted">این گزینه داخل ربات نمایش داده نمی‌شود. مدیر این فرمان را در چت ربات ارسال می‌کند:</p>
                <code class="block dir-ltr text-left break-all">/start admin_<?php echo clean($adminSecret); ?></code>
            </div>
            <div class="stats-mini">
                <span>کاربران متصل</span>
                <b><?php echo tr_num(count($connectedUsers), 'fa'); ?></b>
            </div>
        </section>

        <section class="card col-span-2 shadow-lg space-y-4">
            <h3 class="font-bold text-primary border-b pb-2">📢 ارسال پیام هدفمند</h3>
            <form method="POST" class="space-y-4" id="targetForm">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <input type="hidden" name="send_targeted_message" value="1">
                <div class="grid grid-cols-4 gap-3">
                    <label class="target-card"><input type="radio" name="target_scope" value="all" checked> همه کاربران</label>
                    <label class="target-card"><input type="radio" name="target_scope" value="grade"> پایه تحصیلی</label>
                    <label class="target-card"><input type="radio" name="target_scope" value="class"> کلاس</label>
                    <label class="target-card"><input type="radio" name="target_scope" value="student"> دانش‌آموز</label>
                </div>
                <div class="grid grid-cols-3 gap-3">
                    <select name="target_value_grade" class="form-select target-value" data-scope="grade">
                        <?php foreach ($grades as $g): ?><option value="<?php echo clean($g['grade_level']); ?>"><?php echo clean($g['grade_level']); ?></option><?php endforeach; ?>
                    </select>
                    <select name="target_value_class" class="form-select target-value" data-scope="class">
                        <?php foreach ($classes as $c): ?><option value="<?php echo clean($c['class_name']); ?>"><?php echo clean($c['class_name']); ?></option><?php endforeach; ?>
                    </select>
                    <select name="target_value_student" class="form-select target-value" data-scope="student">
                        <?php foreach ($students as $s): ?><option value="<?php echo (int)$s['id']; ?>"><?php echo clean($s['first_name'] . ' ' . $s['last_name'] . ' - ' . $s['class_name'] . ' - ' . $s['national_id']); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <textarea name="target_message" rows="4" class="form-textarea" placeholder="متن اطلاعیه را بنویسید..." required></textarea>
                <button type="submit" class="btn btn-primary px-8">📨 ارسال به مخاطبان انتخاب‌شده</button>
            </form>
        </section>
    </div>

    <section class="card shadow-lg space-y-5">
        <h3 class="font-bold text-primary border-b pb-2">✏️ شخصی‌سازی پیام‌های ثابت و دکمه‌های ربات</h3>
        <form method="POST" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <input type="hidden" name="save_templates" value="1">
            <div class="grid grid-cols-2 gap-4">
                <?php foreach ($messages as $key => $text): ?>
                    <div>
                        <label class="block text-xs font-semibold mb-1 dir-ltr text-left">message: <?php echo clean($key); ?></label>
                        <textarea name="msg_<?php echo clean($key); ?>" rows="3" class="form-textarea text-xs"><?php echo clean($text); ?></textarea>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="table-container">
                <table>
                    <thead><tr><th>کلید</th><th>متن دکمه</th><th>ردیف</th><th>ترتیب</th><th>فعال</th></tr></thead>
                    <tbody>
                    <?php foreach ($buttons as $key => $b): ?>
                        <tr>
                            <td class="font-mono dir-ltr"><?php echo clean($key); ?></td>
                            <td><input class="form-input" name="btn_text_<?php echo clean($key); ?>" value="<?php echo clean($b['button_text']); ?>"></td>
                            <td><input class="form-input dir-ltr text-left" type="number" min="1" name="btn_row_<?php echo clean($key); ?>" value="<?php echo (int)$b['row_no']; ?>"></td>
                            <td><input class="form-input dir-ltr text-left" type="number" min="1" name="btn_order_<?php echo clean($key); ?>" value="<?php echo (int)$b['sort_order']; ?>"></td>
                            <td><input type="checkbox" name="btn_active_<?php echo clean($key); ?>" <?php echo !empty($b['is_active']) ? 'checked' : ''; ?>></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn btn-success px-8">💾 ذخیره متن‌ها و دکمه‌ها</button>
        </form>
    </section>

    <section class="card shadow-lg">
        <h3 class="font-bold text-primary mb-3">👥 کاربران متصل به ربات <?php echo clean($title); ?></h3>
        <div class="table-container max-h-[420px]">
            <table>
                <thead><tr><th>#</th><th>Chat ID</th><th>Username</th><th>دانش‌آموز</th><th>کد ملی</th><th>پایه</th><th>کلاس</th><th>زمان اتصال</th></tr></thead>
                <tbody>
                <?php foreach ($connectedUsers as $u): ?>
                    <tr>
                        <td><?php echo (int)$u['id']; ?></td>
                        <td class="font-mono dir-ltr text-xs"><?php echo clean($u['chat_id']); ?></td>
                        <td class="font-mono dir-ltr text-xs"><?php echo clean($u['username'] ?: '---'); ?></td>
                        <td class="font-bold text-primary"><?php echo clean($u['first_name'] . ' ' . $u['last_name']); ?></td>
                        <td><?php echo tr_num($u['national_id'], 'fa'); ?></td>
                        <td><?php echo clean($u['grade_level']); ?></td>
                        <td><span class="badge badge-info"><?php echo clean($u['class_name']); ?></span></td>
                        <td class="text-xs text-muted"><?php echo clean($u['created_at']); ?></td>
                    </tr>
                <?php endforeach; if (!$connectedUsers): ?>
                    <tr><td colspan="8" class="text-center text-muted py-6">هنوز کاربری متصل نشده است.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
<script>
(function(){
  const form = document.getElementById('targetForm');
  if (!form) return;
  const refresh = () => {
    const scope = form.querySelector('input[name="target_scope"]:checked')?.value || 'all';
    form.querySelectorAll('.target-value').forEach(el => { el.style.display = (el.dataset.scope === scope) ? '' : 'none'; });
  };
  form.querySelectorAll('input[name="target_scope"]').forEach(r => r.addEventListener('change', refresh));
  refresh();
})();
</script>
        <?php
    }
}
