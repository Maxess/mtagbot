<?php
// File: grade-entry-management.php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/academic_year_helpers.php';
require_once __DIR__ . '/includes/grade_permissions.php';
require_once __DIR__ . '/includes/school_sort.php';
require_permission('manage_reports');
ensure_grade_permissions_schema();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if(!verify_csrf($_POST['csrf_token']??'')){set_flash_message('error','CSRF');redirect('grade-entry-management.php');}
    if(isset($_POST['save_rule'])){
        DB::execute("INSERT INTO grade_entry_permissions (academic_year, report_month, grade_level, class_name, subject_name, teacher_id, can_enter, can_edit, note) VALUES (?,?,?,?,?,?,?,?,?)", [unify_academic_year(trim($_POST['academic_year'])),trim($_POST['report_month']),trim($_POST['grade_level']),trim($_POST['class_name']),trim($_POST['subject_name']),(int)$_POST['teacher_id'],isset($_POST['can_enter'])?1:0,isset($_POST['can_edit'])?1:0,trim($_POST['note'])]);
        set_flash_message('success','قانون ثبت نمره ذخیره شد.');
    }
    if(isset($_POST['delete_rule'])){DB::execute('DELETE FROM grade_entry_permissions WHERE id=?',[(int)$_POST['id']]);set_flash_message('success','قانون حذف شد.');}
    redirect('grade-entry-management.php');
}
require_once __DIR__ . '/includes/header.php';
$year=get_setting('current_academic_year','1404/1405');
$years = get_academic_years_for_filter();
$grades=get_unified_grade_options($year); $classes=get_unified_class_options($year);
$subjects=DB::fetchAll("SELECT DISTINCT subject_name FROM class_schedules WHERE subject_name<>'' UNION SELECT DISTINCT name AS subject_name FROM subjects WHERE name<>'' ORDER BY subject_name");
$teachers=DB::fetchAll("SELECT id,full_name FROM teachers WHERE status=1 ORDER BY full_name");
$rules=DB::fetchAll("SELECT gp.*, t.full_name FROM grade_entry_permissions gp LEFT JOIN teachers t ON t.id=gp.teacher_id ORDER BY gp.id DESC LIMIT 300");
?>
<div class="space-y-4">
 <div class="card"><form method="POST" class="grid grid-cols-6 gap-2 items-end"><input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>"><input type="hidden" name="save_rule" value="1"><div><label>سال</label><select name="academic_year" class="form-select"><?php foreach($years as $y): ?><option value="<?php echo clean($y['academic_year']); ?>"><?php echo clean($y['academic_year']); ?></option><?php endforeach; ?></select></div><div><label>ماه</label><input name="report_month" class="form-input" placeholder="خالی=همه"></div><div><label>پایه</label><select name="grade_level" class="form-select"><option value="">همه</option><?php foreach($grades as $g): ?><option value="<?php echo clean($g['grade_level']); ?>"><?php echo clean($g['grade_level']); ?></option><?php endforeach; ?></select></div><div><label>کلاس</label><select name="class_name" class="form-select"><option value="">همه</option><?php foreach($classes as $c): ?><option value="<?php echo clean($c['class_name']); ?>"><?php echo clean($c['class_name']); ?></option><?php endforeach; ?></select></div><div><label>درس</label><select name="subject_name" class="form-select"><option value="">همه</option><?php foreach($subjects as $s): ?><option value="<?php echo clean($s['subject_name']); ?>"><?php echo clean($s['subject_name']); ?></option><?php endforeach; ?></select></div><div><label>دبیر</label><select name="teacher_id" class="form-select"><option value="0">همه</option><?php foreach($teachers as $t): ?><option value="<?php echo $t['id']; ?>"><?php echo clean($t['full_name']); ?></option><?php endforeach; ?></select></div><label><input type="checkbox" name="can_enter" checked> اجازه ثبت</label><label><input type="checkbox" name="can_edit" checked> اجازه ویرایش</label><input name="note" class="form-input" placeholder="یادداشت"><button class="btn btn-success">ثبت قانون</button></form></div>
 <div class="card"><div class="table-container"><table><thead><tr><th>سال/ماه</th><th>پایه/کلاس</th><th>درس</th><th>دبیر</th><th>ثبت</th><th>ویرایش</th><th>حذف</th></tr></thead><tbody><?php foreach($rules as $r): ?><tr><td><?php echo clean($r['academic_year'].' / '.($r['report_month']?:'همه')); ?></td><td><?php echo clean(($r['grade_level']?:'همه').' / '.($r['class_name']?:'همه')); ?></td><td><?php echo clean($r['subject_name']?:'همه'); ?></td><td><?php echo clean($r['full_name']?:'همه'); ?></td><td><?php echo $r['can_enter']?'✅':'⛔'; ?></td><td><?php echo $r['can_edit']?'✅':'⛔'; ?></td><td><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>"><input type="hidden" name="delete_rule" value="1"><input type="hidden" name="id" value="<?php echo $r['id']; ?>"><button class="btn btn-danger text-xs">حذف</button></form></td></tr><?php endforeach; ?></tbody></table></div></div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
